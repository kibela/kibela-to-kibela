---
id: QmxvZy84Mg
path: "/notes/82"
author: "@owner_user"
contributors:
- "@owner_user"
coediting: true
folder: 
groups:
- Home
published_at: '2019-07-10 14:58:03 +0900'
updated_at: '2019-07-10 14:58:03 +0900'
archived_at: 
comments: []
---

# Orentation情報を持った画像が貼られた記事

![](../attachments/2.jpg)
