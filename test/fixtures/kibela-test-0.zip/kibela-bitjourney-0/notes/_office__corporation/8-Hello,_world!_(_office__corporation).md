---
id: QmxvZy84
path: "/notes/8"
author: "@user_43"
contributors:
- "@user_43"
coediting: true
folder: ":office: corporation"
groups:
- Home
published_at: '2019-06-22 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (:office: corporation)

This is a wiki entry (:office: corporation).

