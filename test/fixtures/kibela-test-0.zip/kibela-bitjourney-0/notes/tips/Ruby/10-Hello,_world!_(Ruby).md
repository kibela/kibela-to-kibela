---
id: QmxvZy8xMA
path: "/notes/10"
author: "@user_36"
contributors:
- "@user_36"
coediting: true
folder: tips/Ruby
groups:
- Home
published_at: '2019-05-21 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (Ruby)

This is a wiki entry (Ruby).

