---
id: QmxvZy85
path: "/@user_36/9"
author: "@user_36"
contributors:
- "@user_36"
coediting: false
folder: tips/Ruby
groups:
- Home
published_at: '2019-05-21 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! to (Ruby)

Hello, world! (Ruby)

blah blah blah

