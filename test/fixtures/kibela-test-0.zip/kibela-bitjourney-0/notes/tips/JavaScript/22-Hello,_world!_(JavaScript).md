---
id: QmxvZy8yMg
path: "/notes/22"
author: "@user_51"
contributors:
- "@user_51"
coediting: true
folder: tips/JavaScript
groups:
- Home
published_at: '2019-05-19 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (JavaScript)

This is a wiki entry (JavaScript).

