---
id: QmxvZy8zNA
path: "/notes/34"
author: "@user_97"
contributors:
- "@user_97"
coediting: true
folder: tips/AWS
groups:
- Home
published_at: '2019-05-29 14:57:57 +0900'
updated_at: '2019-07-10 14:57:57 +0900'
archived_at: 
comments: []
---

# Hello, world! (AWS)

This is a wiki entry (AWS).

