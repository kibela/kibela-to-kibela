---
id: QmxvZy8xMw
path: "/@user_12/13"
author: "@user_12"
contributors:
- "@user_12"
coediting: false
folder: tips/C++
groups:
- Home
published_at: '2019-06-19 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! to (C++)

Hello, world! (C++)

blah blah blah

