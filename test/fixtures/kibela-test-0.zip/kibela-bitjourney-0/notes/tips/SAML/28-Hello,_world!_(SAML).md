---
id: QmxvZy8yOA
path: "/notes/28"
author: "@user_21"
contributors:
- "@user_21"
coediting: true
folder: tips/SAML
groups:
- Home
published_at: '2019-05-14 14:57:56 +0900'
updated_at: '2019-07-10 14:57:57 +0900'
archived_at: 
comments: []
---

# Hello, world! (SAML)

This is a wiki entry (SAML).

