---
id: QmxvZy8xNg
path: "/notes/16"
author: "@user_51"
contributors:
- "@user_51"
coediting: true
folder: tips/TypeScript
groups:
- Home
published_at: '2019-06-20 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (TypeScript)

This is a wiki entry (TypeScript).

