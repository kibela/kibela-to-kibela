---
id: QmxvZy8xNQ
path: "/@user_51/15"
author: "@user_51"
contributors:
- "@user_51"
coediting: false
folder: tips/TypeScript
groups:
- Home
published_at: '2019-06-20 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! to (TypeScript)

Hello, world! (TypeScript)

blah blah blah

