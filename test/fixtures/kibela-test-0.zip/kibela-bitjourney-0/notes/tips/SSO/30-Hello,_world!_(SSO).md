---
id: QmxvZy8zMA
path: "/notes/30"
author: "@user_74"
contributors:
- "@user_74"
coediting: true
folder: tips/SSO
groups:
- Home
published_at: '2019-07-02 14:57:57 +0900'
updated_at: '2019-07-10 14:57:57 +0900'
archived_at: 
comments: []
---

# Hello, world! (SSO)

This is a wiki entry (SSO).

