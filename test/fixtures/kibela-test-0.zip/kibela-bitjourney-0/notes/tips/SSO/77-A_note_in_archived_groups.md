---
id: QmxvZy83Nw
path: "/notes/77"
author: "@owner_user"
contributors:
- "@owner_user"
coediting: true
folder: tips/SSO
groups:
- archived group
published_at: '2019-07-10 14:57:58 +0900'
updated_at: '2019-07-10 14:57:58 +0900'
archived_at: 
comments: []
---

# A note in archived groups

Hello, archived groups!

