---
id: QmxvZy85MA
path: "/notes/90"
author: "@owner_user"
contributors:
- "@owner_user"
coediting: true
folder: 
groups:
- Home
published_at: '2019-07-11 12:23:12 +0900'
updated_at: '2019-07-11 12:59:56 +0900'
archived_at: 
comments:
- id: Q29tbWVudC8xMDE
  path: "/notes/90#comment_101"
  author: "@owner_user"
  published_at: '2019-07-11 12:48:03 +0900'
  updated_at: '2019-07-11 12:48:03 +0900'
  content: "@owner_user Hello!"
- id: Q29tbWVudC8xMDI
  path: "/notes/90#comment_102"
  author: "@owner_user"
  published_at: '2019-07-11 12:48:15 +0900'
  updated_at: '2019-07-11 12:48:15 +0900'
  content: "@admin_user Hello!"
---

# strike!

<del>Hello, @owner_user yey yey</del>

