---
id: QmxvZy84MQ
path: "/notes/81"
author: "@member_user"
contributors:
- "@member_user"
- "@owner_user"
coediting: true
folder: 
groups:
- Home
published_at: '2019-07-10 14:58:02 +0900'
updated_at: '2019-07-10 14:58:02 +0900'
archived_at: 
comments: []
---

# author is not included in contributors

dummy content
