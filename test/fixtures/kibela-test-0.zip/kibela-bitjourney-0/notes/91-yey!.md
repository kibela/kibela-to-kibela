---
id: QmxvZy85MQ
path: "/notes/91"
author: "@owner_user"
contributors:
- "@owner_user"
coediting: true
folder: 
groups:
- Home
published_at: '2019-07-11 12:39:50 +0900'
updated_at: '2019-07-11 12:39:50 +0900'
archived_at: 
comments: []
---

# yey!

Hello, @admin_user !
