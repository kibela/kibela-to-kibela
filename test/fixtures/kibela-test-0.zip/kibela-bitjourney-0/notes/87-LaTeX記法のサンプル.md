---
id: QmxvZy84Nw
path: "/notes/87"
author: "@user_13"
contributors:
- "@user_13"
- "@owner_user"
coediting: true
folder: 
groups:
- Home
- For Guest 1
published_at: '2019-07-10 14:58:03 +0900'
updated_at: '2019-07-10 14:58:03 +0900'
archived_at: 
comments: []
---

# LaTeX記法のサンプル



## inline math

```markdown
$` $\sum_{i=0}^n i^2 = \frac{(n^2+n)(2n+1)}{6}$ `$
```


$` \sum_{i=0}^n i^2 = \frac{(n^2+n)(2n+1)}{6} `$

## display math

~~~markdown
```{latex}
\sum_{i=0}^n i^2 = \frac{(n^2+n)(2n+1)}{6}

```
~~~

```{latex}
\sum_{i=0}^n i^2 = \frac{(n^2+n)(2n+1)}{6}

```

## See Also


* [MathJax basic tutorial and quick reference \- Mathematics Meta Stack Exchange](https://math.meta.stackexchange.com/questions/5020/mathjax-basic-tutorial-and-quick-reference)
* [記事の書き方 \| Kibela Docs](https://docs.kibe.la/help-documents-japanese/%E6%A9%9F%E8%83%BD/%E8%A8%98%E4%BA%8B%E3%81%AE%E6%9B%B8%E3%81%8D%E6%96%B9)


