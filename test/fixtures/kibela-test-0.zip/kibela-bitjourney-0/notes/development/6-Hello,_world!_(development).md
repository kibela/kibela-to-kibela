---
id: QmxvZy82
path: "/notes/6"
author: "@user_15"
contributors:
- "@user_15"
coediting: true
folder: development
groups:
- Home
published_at: '2019-06-06 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (development)

This is a wiki entry (development).

