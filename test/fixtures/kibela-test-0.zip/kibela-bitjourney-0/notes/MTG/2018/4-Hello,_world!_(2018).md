---
id: QmxvZy80
path: "/notes/4"
author: "@user_57"
contributors:
- "@user_57"
coediting: true
folder: MTG/2018
groups:
- Home
published_at: '2019-07-04 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (2018)

This is a wiki entry (2018).

