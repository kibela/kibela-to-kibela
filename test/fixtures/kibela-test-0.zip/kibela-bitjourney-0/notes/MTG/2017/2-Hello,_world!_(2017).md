---
id: QmxvZy8y
path: "/notes/2"
author: "@user_43"
contributors:
- "@user_43"
coediting: true
folder: MTG/2017
groups:
- Home
published_at: '2019-05-12 14:57:56 +0900'
updated_at: '2019-07-10 14:57:56 +0900'
archived_at: 
comments: []
---

# Hello, world! (2017)

This is a wiki entry (2017).

