---
id: QmxvZy83OA
path: "/notes/78"
author: "@owner_user"
contributors:
- "@owner_user"
coediting: true
folder: archived folder
groups:
- Home
published_at: '2019-07-10 14:57:58 +0900'
updated_at: '2019-07-10 14:57:58 +0900'
archived_at: 
comments: []
---

# A note in archived folders

Hello, archived folders!

