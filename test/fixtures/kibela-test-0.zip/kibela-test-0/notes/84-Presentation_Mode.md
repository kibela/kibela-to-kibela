---
id: QmxvZy84NA
path: "/notes/84"
author: "@admin_user"
contributors:
- "@admin_user"
- "@owner_user"
coediting: true
folders: []
groups:
- Home
- For Guest 1
published_at: '2019-07-10 14:58:03 +0900'
updated_at: '2019-07-10 14:58:03 +0900'
archived_at: 
comments: []
---

# Presentation Mode


## :star2: 仕様 :star2: 

* h1, h2, h3, h4, h5, h6 （hx）ではじまる一連の要素が1ページという扱い
    * とはいえそもそも「ページ」という概念が重要ではなくなっている
* 移動は→または↓で進む、←または↑で戻る
* 改ページのための `---` （`<hr/>`）は不要
    * presentation modeでは `hr { display: hidden }` なので単に無視される
* 縦スクロール式
    * コンテンツが長くてもレイアウト崩れは起きない
    * Dropbox Paper も縦スクロール
* 長いコンテンツも適当にスクロールする
* プレビューモードがなくても結果を予想しやすいのがメリット

## コード

```Presentation.jsx
export default class Presentation extends React.Component {

  static get propTypes() {
    return {
      selector: PropTypes.string.isRequired,
    };
  }

  constructor(props) {
    super(props);

    this.onKeydown = this.onKeydown.bind(this);
    this.onKeyup = this.onKeyup.bind(this);
    this.taskRunner = new ThrottledTaskRunner(300);
  }

  render() {
    // ...
  }
}
```

```session.rb
class Session < ActiveRecord::SessionStore::Session
  belongs_to :user, inverse_of: :sessions

  EXPIRES_IN = 2.months

  # @param [User] exclude_user
  def self.sign_out_all_users(exclude_user: nil)
    Session.where.not(user: exclude_user).destroy_all

    # Purge remember me
    User.where.not(id: exclude_user&.id).update_all(remember_created_at: nil, remember_token: nil)
  end

  # see https://github.com/rails/activerecord-session_store/pull/84
  class Serializer
    def self.load(value)
      value
    end

    def self.dump(value)
      value
    end
  end
end
```


## タイトルだけもあり

## h2

### h3

#### h4

##### h5

###### h6

## Raw HTML

生のHTMLもOK! :dancer:

#### 定義リスト:

<dl>
  <dt>Kibela</dt>
  <dd>
    Bit Journey製の情報共有ツール。
  </dd>
  <dt>Groupad</dt>
  <dd>
    Cookpad内製の情報共有ツール。Kibelaの元ネタ。
  </dd>
  <dt>はてなグループ</dt>
  <dd>
    はてなの情報共有ツール。Groupadの元ネタ。
  </dd>
</dl>

#### 表:

<table>
<tr><th>Name</th><th>URL</th></tr>
<tr><td>Kibela</td><td>https://kibe.la/</td></tr>
<tr><td>Qiita::Team</td><td>https://teams.qiita.com/</td></tr>
<tr><td>esa</td><td>https://esa.io//</td></tr>
<tr><td>Confluence</td><td>https://www.atlassian.com/software/confluence</td></tr>
</table>

## PlantUML

もちろんPantUMLもOK

#### (1)

```{plantuml}
Alice -> Bob: Authentication Request
Bob --> Alice: Authentication Response

Alice -> Bob: Another authentication Request
Alice <-- Bob: another authentication Response
```

#### (2)

```{plantuml}
package "Some Group" {
  HTTP - [First Component]
  [Another Component]
}
 
node "Other Groups" {
  FTP - [Second Component]
  [First Component] --> FTP
} 

cloud {
  [Example 1]
}


database "MySql" {
  folder "This is my folder" {
    [Folder 3]
  }
  frame "Foo" {
    [Frame 4]
  }
}


[Another Component] --> [Example 1]
[Example 1] --> [Folder 3]
[Folder 3] --> [Frame 4]
```

## 数式

LaTeX記法もOK！

inlineMath: $$ a = \{ 1, 2, 3 \} $$

displayMath:

```{latex}
\begin{aligned}
\nabla \times \vec{\mathbf{B}} -\, \frac1c\, \frac{\partial\vec{\mathbf{E}}}{\partial t} & = \frac{4\pi}{c}\vec{\mathbf{j}} \\   \nabla \cdot \vec{\mathbf{E}} & = 4 \pi \rho \\
\nabla \times \vec{\mathbf{E}}\, +\, \frac1c\, \frac{\partial\vec{\mathbf{B}}}{\partial t} & = \vec{\mathbf{0}} \\
\nabla \cdot \vec{\mathbf{B}} & = 0 \end{aligned}
```

## 以上

Enjoy Presentation!

