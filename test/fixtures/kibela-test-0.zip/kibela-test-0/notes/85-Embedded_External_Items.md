---
id: QmxvZy84NQ
path: "/notes/85"
author: "@user_15"
contributors:
- "@user_15"
- "@owner_user"
coediting: true
folders: []
groups:
- Home
- For Guest 1
published_at: '2019-07-10 14:58:03 +0900'
updated_at: '2019-07-10 14:58:03 +0900'
archived_at: 
comments: []
---

# Embedded External Items


実装は script_sandbox.rb 参照のこと。

## SpeakerDeck

<script async class="speakerdeck-embed" data-id="0f76b403c00043deada0eaee74e23aa6" data-ratio="1.77777777777778" src="//speakerdeck.com/assets/embed.js"></script>


## SlideShare

<iframe src="//www.slideshare.net/slideshow/embed_code/key/Jxbor4I3Dov0AP" width="595" height="485" frameborder="0" marginwidth="0" marginheight="0" scrolling="no" style="border:1px solid #CCC; border-width:1px; margin-bottom:5px; max-width: 100%;" allowfullscreen> </iframe> <div style="margin-bottom:5px"> <strong> <a href="//www.slideshare.net/kazuho/jsx20130608pptx" title="JSX - developing a statically-typed programming language for the Web" target="_blank">JSX - developing a statically-typed programming language for the Web</a> </strong> from <strong><a href="https://www.slideshare.net/kazuho" target="_blank">Kazuho Oku</a></strong> </div>

## Twitter


<blockquote class="twitter-tweet" data-lang="en"><p lang="ja" dir="ltr">簡単に同じフォルダに記事を書けるようにしました - Kibela Blog <a href="https://t.co/c3mMCQFpkL">https://t.co/c3mMCQFpkL</a> <a href="https://twitter.com/hashtag/Kibela?src=hash&amp;ref_src=twsrc%5Etfw">#Kibela</a></p>&mdash; Kibela (@kibe_la) <a href="https://twitter.com/kibe_la/status/1100697865863622656?ref_src=twsrc%5Etfw">February 27, 2019</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>



